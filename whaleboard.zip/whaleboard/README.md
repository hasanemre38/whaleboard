# WhaleBoard 🐋

Binance Futures verilerini **gerçek zamanlı** takip eden dashboard.
Her 30 saniyede otomatik güncellenir, API key gerekmez.

## Özellikler
- 📊 Open Interest (OI) sıralaması
- 📈 Long / Short oranları (global hesaplar)
- ⚡ Gerçek likidasyonlar (Binance Futures)
- 💰 Funding rate (8 saatlik)
- 🔄 30 saniyede bir otomatik yenileme

## Vercel'e Deploy (5 dakika)

### 1. GitHub'a yükle
```bash
git init
git add .
git commit -m "WhaleBoard ilk versiyon"
# GitHub'da yeni repo oluştur, sonra:
git remote add origin https://github.com/KULLANICI_ADI/whaleboard.git
git push -u origin main
```

### 2. Vercel'de deploy et
1. https://vercel.com adresine git
2. "New Project" → GitHub reposunu seç
3. "Deploy" butonuna bas
4. Bitti! ✅ Vercel sana bir URL verecek (örn: whaleboard.vercel.app)

### 3. Lokal çalıştırma (opsiyonel)
```bash
npm install
npm run dev
# http://localhost:3000
```

## API Kaynakları (Ücretsiz, key gerekmez)
- `https://api.binance.com` — Spot fiyatlar
- `https://fapi.binance.com` — Futures OI, funding, long/short
- Tüm çağrılar server-side yapılır (CORS sorunu yok)
