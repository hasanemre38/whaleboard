'use client';
import { useState, useEffect, useCallback } from 'react';

// ── COLOURS ──────────────────────────────────────────────────────────
const C = {
  bg:'#040810', surf:'#080f1a', surf2:'#0b1625', brd:'#0d1f33',
  acc:'#00d4ff', grn:'#00e87a', red:'#ff2d55', ylw:'#ffc107',
  prp:'#a78bfa', mut:'#2d4a6a', txt:'#8ab4cc', white:'#e8f4ff',
};

// ── FORMAT HELPERS ───────────────────────────────────────────────────
const fmtUSD = n => {
  if (!n && n !== 0) return '—';
  const a = Math.abs(n);
  if (a >= 1e9) return '$' + (a/1e9).toFixed(2) + 'B';
  if (a >= 1e6) return '$' + (a/1e6).toFixed(2) + 'M';
  if (a >= 1e3) return '$' + (a/1e3).toFixed(1) + 'K';
  return '$' + a.toFixed(0);
};
const fmtPrice = n => {
  if (n == null) return '—';
  if (n >= 10000) return '$' + Math.round(n).toLocaleString('en');
  if (n >= 100)   return '$' + n.toFixed(1);
  if (n >= 1)     return '$' + n.toFixed(3);
  return '$' + n.toFixed(5);
};
const chgColor = v => v >= 0 ? C.grn : C.red;
const chgArrow = v => v >= 0 ? '▲ +' : '▼ ';

const TABS = ['📊 Market', '⚡ Likidasyonlar'];

export default function Page() {
  const [tab,      setTab]      = useState(0);
  const [market,   setMarket]   = useState(null);
  const [liqs,     setLiqs]     = useState(null);
  const [loading,  setLoading]  = useState(false);
  const [error,    setError]    = useState(null);
  const [lastUpd,  setLastUpd]  = useState('—');
  const [sort,     setSort]     = useState('oiUsd');
  const [countdown,setCountdown]= useState(30);

  const fetchAll = useCallback(async () => {
    setLoading(true); setError(null);
    try {
      const [mRes, lRes] = await Promise.all([
        fetch('/api/market'),
        fetch('/api/liquidations'),
      ]);
      const [mData, lData] = await Promise.all([mRes.json(), lRes.json()]);
      if (mData.ok)  setMarket(mData);
      if (lData.ok)  setLiqs(lData);
      if (!mData.ok) setError(mData.error);
      setLastUpd(new Date().toLocaleTimeString('tr-TR'));
      setCountdown(30);
    } catch (e) {
      setError(e.message);
    }
    setLoading(false);
  }, []);

  // Initial load
  useEffect(() => { fetchAll(); }, [fetchAll]);

  // Auto-refresh every 30s
  useEffect(() => {
    const t = setInterval(fetchAll, 30000);
    return () => clearInterval(t);
  }, [fetchAll]);

  // Countdown timer
  useEffect(() => {
    const t = setInterval(() => setCountdown(c => c <= 1 ? 30 : c - 1), 1000);
    return () => clearInterval(t);
  }, []);

  const coins = market?.coins ?? [];
  const sorted = [...coins].sort((a, b) =>
    sort === 'oiUsd'   ? b.oiUsd   - a.oiUsd   :
    sort === 'chg24'   ? b.chg24   - a.chg24   :
    sort === 'vol24'   ? b.vol24   - a.vol24   :
    sort === 'fundRate'? Math.abs(b.fundRate) - Math.abs(a.fundRate) : 0
  );

  const btc = coins.find(c => c.sym === 'BTC');
  const eth = coins.find(c => c.sym === 'ETH');
  const avg = coins.length ? coins.reduce((s,c) => s + c.chg24, 0) / coins.length : 0;

  const sent = avg > 4  ? {e:'🔥', l:'AÇGÖZLÜ',  col:C.grn}
             : avg > 1  ? {e:'📈', l:'İYİMSER',  col:C.grn}
             : avg > -1 ? {e:'😐', l:'NÖTR',     col:C.acc}
             : avg > -4 ? {e:'📉', l:'TEMKİNLİ', col:C.red}
             :             {e:'🩸', l:'KORKU',    col:C.red};

  return (
    <div style={{background:C.bg, minHeight:'100vh', fontFamily:"'Barlow Condensed',sans-serif", color:C.txt}}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@400;600;700;900&display=swap');
        @keyframes pulse{0%,100%{opacity:1}50%{opacity:.2}}
        @keyframes spin{to{transform:rotate(360deg)}}
        .dp{animation:pulse 1.3s infinite}
        .spin{animation:spin .7s linear infinite}
        tbody tr:hover td{background:rgba(0,212,255,.04)!important}
        ::-webkit-scrollbar{height:3px;width:3px}
        ::-webkit-scrollbar-thumb{background:#0d1f33;border-radius:2px}
        *{box-sizing:border-box;margin:0;padding:0}
        button{cursor:pointer;font-family:inherit}
      `}</style>

      {/* HEADER */}
      <div style={{background:C.surf, borderBottom:`1px solid ${C.brd}`, padding:'12px 18px', position:'sticky', top:0, zIndex:99, display:'flex', alignItems:'center', justifyContent:'space-between'}}>
        <div style={{display:'flex', alignItems:'center', gap:12}}>
          <span style={{fontFamily:'monospace', fontSize:18, color:C.acc, letterSpacing:4, textShadow:`0 0 20px ${C.acc}55`}}>
            WHALE<span style={{color:C.ylw}}>BOARD</span>
          </span>
          <span style={{fontSize:10, color:C.mut, letterSpacing:2, display:'none'}}>LIVE</span>
        </div>
        <div style={{display:'flex', alignItems:'center', gap:12}}>
          {loading
            ? <div className="spin" style={{width:14, height:14, border:`2px solid ${C.brd}`, borderTopColor:C.acc, borderRadius:'50%'}}/>
            : <div className="dp" style={{width:8, height:8, background:C.grn, borderRadius:'50%', boxShadow:`0 0 8px ${C.grn}`}}/>
          }
          <span style={{fontFamily:'monospace', fontSize:10, color:C.mut}}>{lastUpd}</span>
          <div style={{fontFamily:'monospace', fontSize:10, padding:'3px 8px', background:`rgba(0,212,255,.08)`, border:`1px solid ${C.brd}`, color:C.mut}}>
            {countdown}s
          </div>
          <button onClick={fetchAll} disabled={loading} style={{background:'transparent', border:`1px solid rgba(0,212,255,.3)`, color:C.acc, padding:'6px 12px', fontSize:11, letterSpacing:2, textTransform:'uppercase'}}>
            ⟳ YENİLE
          </button>
        </div>
      </div>

      {/* ERROR */}
      {error && (
        <div style={{background:'rgba(255,45,85,.08)', border:`1px solid rgba(255,45,85,.25)`, margin:'14px', padding:'10px 14px', fontSize:12, color:C.red, letterSpacing:1}}>
          ⚠ {error}
        </div>
      )}

      {/* STAT CARDS */}
      <div style={{display:'grid', gridTemplateColumns:'repeat(4,1fr)', gap:10, padding:'14px 14px 0'}}>
        {[
          {lbl:'BTC', val: btc ? fmtPrice(btc.price) : '—', sub: btc ? chgArrow(btc.chg24)+Math.abs(btc.chg24).toFixed(2)+'%' : '—', col: btc ? chgColor(btc.chg24) : C.acc},
          {lbl:'ETH', val: eth ? fmtPrice(eth.price) : '—', sub: eth ? chgArrow(eth.chg24)+Math.abs(eth.chg24).toFixed(2)+'%' : '—', col: eth ? chgColor(eth.chg24) : C.acc},
          {lbl:'TOPLAM OI', val: market ? fmtUSD(market.summary.totalOI) : '—', sub:'Futures açık faiz', col:C.acc},
          {lbl:'PİYASA', val:`${sent.e} ${sent.l}`, sub:`Ort: ${avg.toFixed(2)}%`, col:sent.col},
        ].map(s => (
          <div key={s.lbl} style={{background:C.surf, border:`1px solid ${C.brd}`, padding:'12px 14px', position:'relative', overflow:'hidden'}}>
            <div style={{position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,transparent,${s.col},transparent)`, opacity:.3}}/>
            <div style={{fontSize:9, letterSpacing:2, color:C.mut, textTransform:'uppercase', marginBottom:5}}>{s.lbl}</div>
            <div style={{fontFamily:'monospace', fontSize:16, color:s.col, fontWeight:700}}>{s.val}</div>
            <div style={{fontSize:10, color:s.col, marginTop:3, opacity:.8}}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* TABS */}
      <div style={{display:'flex', borderBottom:`1px solid ${C.brd}`, background:C.surf, margin:'14px 14px 0'}}>
        {TABS.map((t,i) => (
          <button key={t} onClick={() => setTab(i)} style={{flex:1, padding:'11px 8px', background:'transparent', border:'none', borderBottom:tab===i?`2px solid ${C.acc}`:'2px solid transparent', color:tab===i?C.acc:C.mut, fontSize:12, letterSpacing:2, textTransform:'uppercase'}}>
            {t}
          </button>
        ))}
      </div>

      <div style={{padding:'14px'}}>

        {/* ── TAB 0: MARKET ─────────────────────────────── */}
        {tab === 0 && (
          <>
            {/* Sort buttons */}
            <div style={{display:'flex', gap:6, marginBottom:12, flexWrap:'wrap', alignItems:'center'}}>
              <span style={{fontSize:10, color:C.mut, letterSpacing:2}}>SIRALA:</span>
              {[['oiUsd','OI (USDT)'],['chg24','24s %'],['vol24','Hacim'],['fundRate','Funding']].map(([k,l]) => (
                <button key={k} onClick={() => setSort(k)} style={{padding:'4px 10px', background:sort===k?`rgba(0,212,255,.12)`:'transparent', border:`1px solid ${sort===k?C.acc:C.brd}`, color:sort===k?C.acc:C.mut, fontSize:10, letterSpacing:1, textTransform:'uppercase'}}>
                  {l}
                </button>
              ))}
            </div>

            <div style={{background:C.surf, border:`1px solid ${C.brd}`, overflow:'hidden'}}>
              <div style={{padding:'9px 15px', borderBottom:`1px solid ${C.brd}`, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                <span style={{fontSize:11, letterSpacing:3, color:C.acc, textTransform:'uppercase', fontWeight:600}}>Futures — Açık Faiz & Long/Short</span>
                <span style={{fontFamily:'monospace', fontSize:10, padding:'2px 7px', background:'rgba(0,212,255,.1)', border:`1px solid rgba(0,212,255,.2)`, color:C.acc}}>BİNANCE</span>
              </div>
              <div style={{overflowX:'auto'}}>
                <table style={{width:'100%', borderCollapse:'collapse'}}>
                  <thead>
                    <tr style={{background:'rgba(13,31,51,.7)'}}>
                      {['#','KOİN','FİYAT','24s %','OI (USDT)','LONG','SHORT','LONG/SHORT','FON. ORANI','HAC. 24s'].map((h,i) => (
                        <th key={h} style={{padding:'8px 10px', textAlign:i<=1?'left':'right', fontSize:9, letterSpacing:1.5, textTransform:'uppercase', color:C.mut, fontWeight:400, borderBottom:`1px solid ${C.brd}`, whiteSpace:'nowrap'}}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {sorted.length === 0 ? (
                      <tr><td colSpan={10} style={{textAlign:'center', padding:30, color:C.mut, fontFamily:'monospace', fontSize:11, letterSpacing:2}}>
                        {loading ? '⟳ YÜKLENİYOR...' : 'Veri bekleniyor'}
                      </td></tr>
                    ) : sorted.map((c, i) => (
                      <tr key={c.sym}>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, color:C.mut, fontFamily:'monospace', fontSize:13}}>{i+1}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`}}>
                          <div style={{fontFamily:'monospace', fontWeight:700, fontSize:14, color:C.white, letterSpacing:1}}>{c.sym}</div>
                        </td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.white, fontWeight:700}}>{fmtPrice(c.price)}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', fontWeight:700, color:chgColor(c.chg24)}}>
                          {chgArrow(c.chg24)}{Math.abs(c.chg24).toFixed(2)}%
                        </td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.txt}}>{fmtUSD(c.oiUsd)}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.grn, fontWeight:700}}>{c.longPct.toFixed(1)}%</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.red, fontWeight:700}}>{c.shortPct.toFixed(1)}%</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right'}}>
                          <div style={{minWidth:80, display:'inline-block'}}>
                            <div style={{height:4, borderRadius:2, background:C.brd, overflow:'hidden', display:'flex', marginBottom:2}}>
                              <div style={{width:c.longPct+'%', background:C.grn, height:'100%'}}/>
                              <div style={{width:c.shortPct+'%', background:C.red, height:'100%'}}/>
                            </div>
                          </div>
                        </td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right'}}>
                          <span style={{display:'inline-block', padding:'2px 7px', fontFamily:'monospace', fontSize:11, fontWeight:700, background:c.fundRate>=0?'rgba(0,232,122,.1)':'rgba(255,45,85,.1)', color:c.fundRate>=0?C.grn:C.red, border:`1px solid ${c.fundRate>=0?'rgba(0,232,122,.25)':'rgba(255,45,85,.25)'}`}}>
                            {c.fundRate>=0?'+':''}{c.fundRate.toFixed(4)}%
                          </span>
                        </td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.mut, fontSize:12}}>{fmtUSD(c.vol24)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        {/* ── TAB 1: LİKİDASYONLAR ──────────────────────── */}
        {tab === 1 && (
          <>
            <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:13}}>
              <div style={{background:C.surf, border:`1px solid ${C.brd}`, padding:'13px 15px', position:'relative', overflow:'hidden'}}>
                <div style={{position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,transparent,${C.red},transparent)`, opacity:.4}}/>
                <div style={{fontSize:10, letterSpacing:2, color:C.mut, textTransform:'uppercase', marginBottom:5}}>LONG Likidasyonlar</div>
                <div style={{fontFamily:'monospace', fontSize:20, color:C.red, fontWeight:700}}>{liqs ? fmtUSD(liqs.totalLong) : '—'}</div>
                <div style={{fontSize:11, color:C.mut, marginTop:3}}>Long pozisyon tasfiye</div>
              </div>
              <div style={{background:C.surf, border:`1px solid ${C.brd}`, padding:'13px 15px', position:'relative', overflow:'hidden'}}>
                <div style={{position:'absolute', top:0, left:0, right:0, height:2, background:`linear-gradient(90deg,transparent,${C.grn},transparent)`, opacity:.4}}/>
                <div style={{fontSize:10, letterSpacing:2, color:C.mut, textTransform:'uppercase', marginBottom:5}}>SHORT Likidasyonlar</div>
                <div style={{fontFamily:'monospace', fontSize:20, color:C.grn, fontWeight:700}}>{liqs ? fmtUSD(liqs.totalShort) : '—'}</div>
                <div style={{fontSize:11, color:C.mut, marginTop:3}}>Short pozisyon tasfiye</div>
              </div>
            </div>

            <div style={{background:C.surf, border:`1px solid ${C.brd}`, overflow:'hidden'}}>
              <div style={{padding:'9px 15px', borderBottom:`1px solid ${C.brd}`, display:'flex', justifyContent:'space-between', alignItems:'center'}}>
                <span style={{fontSize:11, letterSpacing:3, color:C.acc, textTransform:'uppercase', fontWeight:600}}>Son Likidasyonlar</span>
                <div style={{display:'flex', alignItems:'center', gap:7}}>
                  <div className="dp" style={{width:6, height:6, background:C.red, borderRadius:'50%'}}/>
                  <span style={{fontFamily:'monospace', fontSize:10, color:C.red, letterSpacing:2}}>BİNANCE FUTURES</span>
                </div>
              </div>
              <div style={{overflowX:'auto'}}>
                <table style={{width:'100%', borderCollapse:'collapse'}}>
                  <thead>
                    <tr style={{background:'rgba(13,31,51,.7)'}}>
                      {['SAAT','KOİN','TİP','FİYAT','MİKTAR','USDT DEĞERİ'].map((h,i) => (
                        <th key={h} style={{padding:'8px 10px', textAlign:i<=1?'left':'right', fontSize:9, letterSpacing:1.5, textTransform:'uppercase', color:C.mut, fontWeight:400, borderBottom:`1px solid ${C.brd}`}}>{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {!liqs?.liquidations?.length ? (
                      <tr><td colSpan={6} style={{textAlign:'center', padding:28, color:C.mut, fontFamily:'monospace', fontSize:11, letterSpacing:2}}>
                        {loading ? '⟳ YÜKLENİYOR...' : 'Veri bekleniyor'}
                      </td></tr>
                    ) : liqs.liquidations.map((l, i) => (
                      <tr key={i}>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, fontFamily:'monospace', color:C.mut, fontSize:12}}>{l.time}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, fontFamily:'monospace', fontWeight:700, color:C.white, fontSize:14}}>{l.sym}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right'}}>
                          <span style={{display:'inline-block', padding:'2px 8px', fontFamily:'monospace', fontSize:10, fontWeight:700, background:l.dir==='LONG'?'rgba(255,45,85,.12)':'rgba(0,232,122,.12)', color:l.dir==='LONG'?C.red:C.grn, border:`1px solid ${l.dir==='LONG'?'rgba(255,45,85,.3)':'rgba(0,232,122,.3)'}`}}>
                            {l.dir==='LONG'?'📉':'📈'} {l.side}
                          </span>
                        </td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.txt}}>{fmtPrice(l.price)}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', color:C.mut, fontSize:12}}>{l.qty.toFixed(3)}</td>
                        <td style={{padding:'10px 10px', borderBottom:`1px solid rgba(13,31,51,.9)`, textAlign:'right', fontFamily:'monospace', fontWeight:700, color:l.dir==='LONG'?C.red:C.grn, fontSize:14}}>{fmtUSD(l.usd)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </>
        )}

        <div style={{textAlign:'center', padding:12, color:C.mut, fontSize:10, letterSpacing:2, borderTop:`1px solid ${C.brd}`, marginTop:4}}>
          WHALEBOARD • Binance Public API • Her 30s otomatik güncellenir • Yatırım tavsiyesi değildir
        </div>
      </div>
    </div>
  );
}
