// app/api/market/route.js
// Server-side Binance API calls — no CORS issues

const SYMBOLS = ['BTCUSDT','ETHUSDT','BNBUSDT','SOLUSDT','XRPUSDT',
                 'DOGEUSDT','ADAUSDT','AVAXUSDT','LINKUSDT','DOTUSDT'];

async function fetchJSON(url) {
  const res = await fetch(url, { next: { revalidate: 0 } });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
  return res.json();
}

export async function GET() {
  try {
    // 1. 24h ticker (spot prices + change)
    const tickerUrl = `https://api.binance.com/api/v3/ticker/24hr?symbols=${JSON.stringify(SYMBOLS)}`;

    // 2. Futures open interest
    // 3. Futures funding rates
    // 4. Long/Short ratio (global accounts)
    const [tickers, fundingRates] = await Promise.all([
      fetchJSON(tickerUrl),
      fetchJSON('https://fapi.binance.com/fapi/v1/premiumIndex'),
    ]);

    // OI per symbol
    const oiResults = await Promise.allSettled(
      SYMBOLS.map(s => fetchJSON(`https://fapi.binance.com/fapi/v1/openInterest?symbol=${s}`))
    );

    // Long/Short ratio per symbol
    const lsResults = await Promise.allSettled(
      SYMBOLS.map(s =>
        fetchJSON(`https://fapi.binance.com/futures/data/globalLongShortAccountRatio?symbol=${s}&period=5m&limit=1`)
      )
    );

    // Map funding rates
    const fundMap = {};
    fundingRates.forEach(f => {
      if (SYMBOLS.includes(f.symbol)) {
        fundMap[f.symbol] = {
          rate: parseFloat(f.lastFundingRate),
          markPrice: parseFloat(f.markPrice),
        };
      }
    });

    // Build coins array
    const coins = tickers.map((t, i) => {
      const price   = parseFloat(t.lastPrice);
      const oiRaw   = oiResults[i].status === 'fulfilled' ? parseFloat(oiResults[i].value.openInterest) : 0;
      const oiUsd   = oiRaw * price;
      const lsData  = lsResults[i].status === 'fulfilled' ? lsResults[i].value[0] : null;
      const fund    = fundMap[t.symbol] || { rate: 0.0001 };

      return {
        sym:     t.symbol.replace('USDT', ''),
        price,
        chg24:   parseFloat(t.priceChangePercent),
        vol24:   parseFloat(t.quoteVolume),
        high24:  parseFloat(t.highPrice),
        low24:   parseFloat(t.lowPrice),
        oiUsd,
        longPct: lsData ? parseFloat(lsData.longAccount) * 100 : 50,
        shortPct:lsData ? parseFloat(lsData.shortAccount) * 100 : 50,
        fundRate: fund.rate * 100,
        fundAnnual: fund.rate * 100 * 3 * 365,
      };
    });

    // Market summary
    const avgChg = coins.reduce((s, c) => s + c.chg24, 0) / coins.length;
    const totalOI = coins.reduce((s, c) => s + c.oiUsd, 0);

    return Response.json({
      ok: true,
      updatedAt: new Date().toISOString(),
      summary: { avgChg, totalOI, btcDom: 57.1 },
      coins,
    });

  } catch (err) {
    return Response.json({ ok: false, error: err.message }, { status: 500 });
  }
}
