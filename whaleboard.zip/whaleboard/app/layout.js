export const metadata = { title: 'WhaleBoard — Kripto Takip', description: 'Binance Futures OI, Long/Short, Likidasyonlar' }
export default function RootLayout({ children }) {
  return (
    <html lang="tr">
      <body style={{margin:0, padding:0, background:'#040810'}}>{children}</body>
    </html>
  )
}
